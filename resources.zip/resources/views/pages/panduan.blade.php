@extends('layouts.index')

@section('content')<div class="container">
<div class="row justify-content-center">
    <div class="col-md-12">
        <div class="card shadow">
            <div class="card-header bg-primary text-white">{{ __('Sistem Informasi Tata Ruang') }}</div>
            <div class="card-body">
                <h4 style="font-weight: bold;">Panduan</h4>
                <hr>
            </div>
        </div>
    </div>
</div>
@endsection